# Baseline-campaign evidence (paper Results "language-model baselines", Fig. 6)

Three frozen record directories backing the three-condition comparison on
the 31-session process-aware suite (96 user turns, all eleven workflows):

| Directory | Condition | Key files |
|---|---|---|
| `exp42_bare_llm_baseline/` | Bare model, zero- and few-shot, no tools (one call per turn per regime) | `runs.jsonl` (192 turn records, verbatim model responses), `adjudicated.jsonl` (validity checks + claim verdicts), `summary.json` |
| `exp43_react_baseline/` | Same-tool ReAct loop, three budget tiers (matched / 3x / 10x) | `runs.jsonl` (288 turn records: budgets, tool logs, submitted answers), `adjudicated.jsonl`, `summary.json` |
| `exp42_43_comparison/` | Three-arm comparison vs the frozen platform records | `comparison.json` (delivery by workflow x condition, failure-mode decomposition, paired exact-McNemar tests, claim adjudication, cost ledger), `table.md` |

Notes:

- The platform condition is NOT re-run: it reuses the frozen production
  records (per-session success, model-call counts and evaluated-candidate
  counts extracted from them; the symmetric validity rules re-applied to
  the frozen candidate pools).
- The `scratch/` subdirectories of the two campaign records (intermediate
  FASTAs written during deterministic adjudication) are regenerable
  operational debris and are excluded; every published number recomputes
  from the JSONL records without them.
- Budget tiers: "matched" = the platform's own measured per-session
  model-call count (zero on the eight deterministic-workflow sessions -
  recorded as the measured floor); "3x"/"10x" = three and ten times
  max(platform count, two calls per turn).
