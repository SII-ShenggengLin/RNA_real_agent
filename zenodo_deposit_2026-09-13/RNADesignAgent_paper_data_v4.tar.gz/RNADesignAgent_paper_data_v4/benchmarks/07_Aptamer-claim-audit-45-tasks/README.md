# Aptamer claim-audit set (45 tasks)

`e5_audit_tasks.json` — the 45-task aptamer claim-overreach audit set: 24
trusted-deterministic tasks with exactly recomputable ground truth and 21
untrusted-predictor ranking/screening tasks spanning the nine-target anchor set. Built
from an earlier registered 20-task set carried byte-verbatim plus pre-registered,
assertion-checked extension rules (the legacy reference is retained alongside as
`e5_legacy_audit_tasks_reference.json`). Consumed by the ungated-control and
gated-treatment conditions of the paper's gating experiments (Supplementary Methods M2).
