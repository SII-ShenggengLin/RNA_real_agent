# Full-length mRNA claim-audit set (20 tasks)

`e18_audit_tasks_mrna.json` — the 20-task full-length mRNA audit set: ten
trusted-deterministic and ten untrusted-predictor tasks built from the 20-target
full-length benchmark's real design assets (production CDS deliveries, top-ranked
full-length constructs, live predictor scores). Consumed by the two-condition gating
replication of the paper (Supplementary Methods M2).
