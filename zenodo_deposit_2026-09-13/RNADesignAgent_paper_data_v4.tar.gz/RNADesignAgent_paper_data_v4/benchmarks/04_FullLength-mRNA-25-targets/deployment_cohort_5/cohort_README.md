# Deployment cohorts

The paper's pooled constraint-navigation analyses (25 mRNA targets, 26 aptamer targets)
combine each registered 20-target suite with a deployment cohort that entered through the
production user-form entry:

- `mrna_targets.json` — the five mRNA deployment targets (PTH, leptin, G-CSF,
  thrombopoietin, PLAT), registered before any run: single UniProt isoform per target,
  accession and length asserted, sequences included, with the selection rule and
  per-target rationale.
- `aptamer_targets.json` — the six aptamer deployment targets (FGF2, Angiopoietin-2,
  IFN-gamma, IL-17A, PDGF-BB, Influenza H3N2 HA). Each is an expanded-pool target entry;
  the definitive records (sequence, provenance, structure path) live in
`../RNA-BioBench-Aptamer-Expanded/targets/` — this register lists the target ids and
  points there.

The cohorts' comparison conditions were completed under the identical budget-matched
protocols and the pooled statistics are reported with cohort splits disclosed (Methods,
Statistics).
