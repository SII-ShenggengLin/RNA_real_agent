# RNADesignAgent — Research Data Deposit (v4.0)

Data supporting the manuscript "A multi-agent system for RNA design with
capability-gated prediction and constraint-navigated generation" (system name
RNADesignAgent; benchmark name RNADesign-210).

v4.0 reorganizes the deposit around the eight final-form benchmark datasets of the
paper's Methods (Benchmark datasets and anchor sets). Each pooled dataset carries a
`dataset_manifest.json` recording per-target provenance (pre-registered benchmark
versus deployment cohort versus expanded pool).

## Contents

### The eight benchmark datasets (benchmarks/)

1. `01_RNADesign-210` — the 210-task system benchmark covering the eleven workflows.
2. `02_ProcessAware-31-sessions` — the 31-session process-aware benchmark (the task set
   of the external-baseline comparison; includes the session registry).
3. `03_SelectionPool-5-proteins` — the five-protein selection pool (A1AT, insulin, EPO,
   GFP, IL-2).
4. `04_FullLength-mRNA-25-targets` — the 25-target pooled full-length mRNA set
   (pre-registered 20 + deployment cohort 5).
5. `05_Aptamer-26-targets` — the 26-target pooled aptamer set (pre-registered 20 +
   deployment cohort 6).
6. `06_Aptamer-budget-sweep-39-targets` — the 39-target budget-sweep pool
   (pre-registered 20 + expanded 19).
7. `07_Aptamer-claim-audit-45-tasks` — the 45-task aptamer claim-audit set.
8. `08_FullLength-claim-audit-20-tasks` — the 20-task full-length mRNA claim-audit set.

### Reference and evidence assets

- `benchmarks/external_anchors/` — the external anchor sets used for capability
  profiling and the biological-validity comparisons (wild-type CDSs with the 200 random
  synonymous controls, aptamer binder and negative groups, measured-MRL 5'UTR
  libraries, IRES anchor set, small-molecule binder and non-binder pairs,
  vaccine-mRNA assemblies, mRNA-stability set).
- `self_model/` — the packaged capability map with its generator.
- `baseline_evidence/` — the frozen records of the comparison against external agent
  baselines (bare-model and same-tool agent-loop campaign records; three-condition
  comparison output).
- `MODEL_API_USAGE.md` — the per-experiment model-usage register.

`MANIFEST.sha256` lists the SHA-256 checksum of every file.
