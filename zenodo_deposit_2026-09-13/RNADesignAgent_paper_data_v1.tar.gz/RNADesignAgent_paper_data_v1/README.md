# RNADesignAgent — Research Data Deposit (v1.0)

Data supporting the manuscript *"A multi-agent system for RNA design with capability-gated
prediction and constraint-navigated generation"* (system name **RNADesignAgent**; benchmark
name **RNADesign-210**).

The deposit contains every frozen evidence record behind the paper's reported numbers:
benchmark and anchor assets, per-campaign verdict files and run records, the packaged
capability self-model, the per-experiment model-usage register, and the supplementary
information documents. `MANIFEST.sha256` lists the SHA-256 checksum of every file.

## Contents

| Path | Contents |
|------|----------|
| `benchmarks/` | The five benchmark suites used in the paper — `RNA-BioBench-Platform` (the 210-task RNADesign-210 suite spanning all eleven workflows), `RNA-BioBench-ProcessAware` (31 multi-turn form-entry regression sessions), `RNA-BioBench-FullLength-mRNA` (20-target full-length mRNA suite), `RNA-BioBench-Aptamer` (20-target aptamer suite), `RNA-BioBench-Aptamer-Expanded` (39-target expanded aptamer pool) — plus `external_anchors/` (the assertion-curated anchor sets used for capability profiling: aptamer binder/negative panels with measured Kd values, the measured-MRL 5′UTR anchor families, IRES positive/negative panel, small-molecule binder/non-binder pairs, mRNA-stability panel) and a per-suite `README.md` describing provenance. |
| `pa_benchmarks.json` | Configuration of the 31 process-aware benchmark sessions (task inputs as entered through the user form). |
| `campaigns/` | Frozen per-campaign evidence under `experiments/results/` as of the manuscript version: pre-registered drivers' verdict/summary files, per-target dual-arm records, adjudication materials (including sealed blinding maps), audit-trail slices with SHA-256 manifests, navigation traces, per-worker reproducibility caches, and the selection-layer pool records. Directory names retain the project's internal experiment identifiers (e.g. `exp28_gennav_mrna_endpoint_v2`) verbatim, because `supplementary/PAPER_FACT_SHEET.md` maps every number printed in the paper to a file by that name. `MODEL_API_USAGE.md` is the authoritative per-experiment LLM-usage register (written in Chinese; the LLM-usage numbers appear in English in the paper's Methods). |
| `self_model/` | The packaged default capability SelfModel (`default_self_model.json`) that ships with the platform and its generator (`build_default_self_model.py`), built from the frozen profiling verdict files — production gating enforces exactly these grades. |
| `supplementary/` | The paper's supplementary information (`SUPPLEMENTARY_INFORMATION.md`, `SUPPLEMENTARY_GENNAV_APTAMER.md`) and the number-to-source-file fact-check table (`PAPER_FACT_SHEET.md`). |

## Notes on provenance and integrity

- **Records are frozen verbatim.** Campaign records were written once and re-verified
  byte-identically (`--verify` recomputation) at freeze time; they are deposited unmodified.
  Two verbatim consequences are disclosed here: (i) some record fields contain absolute
  paths of the analysis cluster where the experiments ran; (ii) operational log files were
  excluded from the deposit (they are not evidence records), everything else is included.
- **Third-party reference databases are not redistributed.** External references used for
  scoring (for example, the human GENCODE v46 transcriptome for siRNA off-target scanning,
  and the codon-usage tables derived from Kazusa) are not part of this deposit; the
  manuscript names them and their accessions. The anchor sets under
  `benchmarks/external_anchors/` are our curation (sequence, role label, measured value,
  and per-entry source citation) of published measurements — chiefly the massively
  parallel translation assay of Sample et al. (GEO accession GSE114002), literature
  aptamer–target binding affinities, and RNA–protein complexes from the RCSB Protein
  Data Bank — assembled under the assertion-checked curation protocol described in the
  manuscript (Methods).
- **Local model weights and external codes are not included.** All structure/sequence
  predictors ran as local microservices with local weights; their vendored upstream codes
  and weights are covered by the manuscript's code-availability statement, not this deposit.

## Intended use

The deposit allows every quantitative statement in the manuscript to be re-derived: each
figure panel's underlying table, every statistical test's input units, the capability
grades behind each gate decision, and the budget-matching ledgers behind every comparative
claim. The mapping from each printed number to its file here is given in
`supplementary/PAPER_FACT_SHEET.md`.

## Licence

Creative Commons Attribution 4.0 International (CC-BY-4.0), to the extent the deposit's
contents are protectable; curated anchor entries remain subject to their original sources'
terms, which are cited per entry.
