# Claim-audit task sets

The two derived task sets behind the paper's claim-gating experiments:

- `e5_audit_tasks.json` — the 45-task aptamer claim-overreach audit set: 24
  trusted-deterministic tasks with exactly recomputable ground truth and 21
  untrusted-predictor ranking/screening tasks spanning the nine-target anchor set. Built
  from an earlier registered 20-task set carried byte-verbatim plus pre-registered,
  assertion-checked extension rules (the legacy reference is retained alongside as
  `e5_legacy_audit_tasks_reference.json`).
- `e18_audit_tasks_mrna.json` — the 20-task full-length mRNA audit set: ten
  trusted-deterministic and ten untrusted-predictor tasks built from the 20-target
  full-length suite's real design assets (production CDS deliveries, top-ranked
  full-length constructs, live predictor scores).

Both are consumed by the ungated-control and gated-treatment conditions of the paper's
gating experiments (Supplementary Methods).
